const Footer = () => {
  return (
    <footer className="py-12 bg-background border-t border-border">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <h3 className="text-2xl font-bold text-neon mb-2">E FOR EDIT</h3>
            <p className="text-muted-foreground">
              Professional Video Editing Services by <span className="text-primary font-semibold">Shakir Uddin</span>
            </p>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-muted-foreground mb-2">
              © 2024 E FOR EDIT. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground">
              Crafted with passion for visual storytelling
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;