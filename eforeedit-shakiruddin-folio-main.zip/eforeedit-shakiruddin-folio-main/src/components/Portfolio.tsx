import { useEffect, useRef } from 'react';
import portfolio1 from '@/assets/portfolio-1.jpg';
import portfolio2 from '@/assets/portfolio-2.jpg';
import portfolio3 from '@/assets/portfolio-3.jpg';
import portfolio4 from '@/assets/portfolio-4.jpg';
import portfolio5 from '@/assets/portfolio-5.jpg';
import portfolio6 from '@/assets/portfolio-6.jpg';

const Portfolio = () => {
  const portfolioRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.animate-fade-in');
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add('in-view');
              }, index * 150);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (portfolioRef.current) {
      observer.observe(portfolioRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const projects = [
    {
      id: 1,
      title: 'Music Video Production',
      category: 'Music Video',
      image: portfolio1,
      description: 'Dynamic music video editing with cinematic color grading and rhythm-based cuts.'
    },
    {
      id: 2,
      title: 'Corporate Training',
      category: 'Corporate',
      image: portfolio2,
      description: 'Professional corporate video with clean transitions and engaging graphics.'
    },
    {
      id: 3,
      title: 'Wedding Highlights',
      category: 'Wedding',
      image: portfolio3,
      description: 'Emotional wedding video capturing the most precious moments with elegance.'
    },
    {
      id: 4,
      title: 'Gaming Content',
      category: 'YouTube',
      image: portfolio4,
      description: 'High-energy gaming content with dynamic transitions and engaging effects.'
    },
    {
      id: 5,
      title: 'Product Commercial',
      category: 'Commercial',
      image: portfolio5,
      description: 'Sleek product showcase with motion graphics and brand integration.'
    },
    {
      id: 6,
      title: 'Documentary Film',
      category: 'Documentary',
      image: portfolio6,
      description: 'Compelling documentary storytelling with professional interview editing.'
    }
  ];

  return (
    <section id="portfolio" ref={portfolioRef} className="py-20">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            <span className="text-foreground">My</span> <span className="text-neon">Portfolio</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground animate-fade-in max-w-2xl mx-auto">
            Explore a selection of my recent video editing projects across various genres and styles.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div 
              key={project.id}
              className="card-portfolio animate-fade-in group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="inline-block px-3 py-1 bg-primary text-primary-foreground text-sm font-medium rounded-full mb-2">
                    {project.category}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;