import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MessageCircle, Instagram, Youtube } from 'lucide-react';

const Contact = () => {
  const contactRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.animate-fade-in, .animate-slide-in-left, .animate-slide-in-right');
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add('in-view');
              }, index * 200);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (contactRef.current) {
      observer.observe(contactRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const contactMethods = [
    {
      icon: Mail,
      title: 'Email',
      detail: 'shakir@eforedit.com',
      link: 'mailto:shakir@eforedit.com'
    },
    {
      icon: Phone,
      title: 'Phone',
      detail: '+1 (555) 123-4567',
      link: 'tel:+15551234567'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      detail: 'Quick Chat',
      link: 'https://wa.me/15551234567'
    }
  ];

  const socialLinks = [
    {
      icon: Instagram,
      name: 'Instagram',
      link: 'https://instagram.com/eforedit'
    },
    {
      icon: Youtube,
      name: 'YouTube',
      link: 'https://youtube.com/@eforedit'
    }
  ];

  return (
    <section id="contact" ref={contactRef} className="py-20 bg-secondary/20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-8 animate-fade-in">
            <span className="text-foreground">Let's</span> <span className="text-neon">Connect</span>
          </h2>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-16 animate-slide-in-left leading-relaxed">
            Ready to bring your video project to life? Get in touch for a free consultation 
            and let's discuss how we can create something amazing together.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 animate-slide-in-right">
            {contactMethods.map((method, index) => {
              const IconComponent = method.icon;
              return (
                <a
                  key={method.title}
                  href={method.link}
                  className="group p-8 bg-card border border-border rounded-xl hover:border-primary transition-all duration-300 hover:scale-105"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <IconComponent className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
                  <h3 className="text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors duration-300">
                    {method.title}
                  </h3>
                  <p className="text-muted-foreground">{method.detail}</p>
                </a>
              );
            })}
          </div>
          
          <div className="animate-fade-in">
            <h3 className="text-2xl font-bold mb-8 text-foreground">Follow My Work</h3>
            <div className="flex justify-center gap-6">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={social.name}
                    href={social.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group p-4 bg-card border border-border rounded-xl hover:border-primary transition-all duration-300 hover:scale-110"
                    style={{ animationDelay: `${index * 150}ms` }}
                  >
                    <IconComponent className="w-8 h-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                  </a>
                );
              })}
            </div>
          </div>
          
          <div className="mt-16 animate-fade-in">
            <Button className="btn-hero text-lg px-12 py-6">
              <Mail className="w-5 h-5 mr-2" />
              Start Your Project
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;