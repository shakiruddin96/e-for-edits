import { useEffect, useRef } from 'react';

const About = () => {
  const aboutRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.animate-fade-in, .animate-slide-in-left, .animate-slide-in-right');
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add('in-view');
              }, index * 200);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (aboutRef.current) {
      observer.observe(aboutRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const skills = [
    'Video Editing',
    'Color Grading',
    'Motion Graphics',
    'Sound Design',
    'Visual Effects',
    'Story Telling'
  ];

  return (
    <section id="about" ref={aboutRef} className="py-20 bg-secondary/20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-8 animate-fade-in">
            <span className="text-neon">About</span> <span className="text-foreground">Me</span>
          </h2>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-12 animate-slide-in-left leading-relaxed">
            With years of experience in video editing and post-production, I specialize in creating 
            compelling visual narratives that captivate audiences. From corporate videos to music videos, 
            documentaries to commercials, I bring technical expertise and creative vision to every project.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6 animate-slide-in-right">
            {skills.map((skill, index) => (
              <div 
                key={skill}
                className="p-6 bg-card border border-border rounded-xl hover:border-primary transition-all duration-300"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <h3 className="text-lg font-semibold text-primary">{skill}</h3>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;